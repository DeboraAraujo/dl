HelloLucene
===========

Mavenized version of Kelvin Tan's example (http://www.lucenetutorial.com/lucene-in-5-minutes.html)

Use the following command to run the program:
```
$ mvn package -q
```
