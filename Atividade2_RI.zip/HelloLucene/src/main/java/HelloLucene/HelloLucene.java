package HelloLucene;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.StringTokenizer;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopScoreDocCollector;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.RAMDirectory;
import org.apache.lucene.util.Version;

public class HelloLucene {

	public static void main(String[] args) throws IOException, ParseException {
		
		StandardAnalyzer analyzer = new StandardAnalyzer(Version.LUCENE_40);
		Directory index = new RAMDirectory();

		IndexWriterConfig config = new IndexWriterConfig(Version.LUCENE_40, analyzer);

		//***** Pegar .CSV *****
		IndexWriter w = new IndexWriter(index, config);
		addDoc(w, "(19) 3309-0005 (19) 9104-1713", "wjschiavi@gmail.com.br", "VERANEIO", "72",
				"mecanica da a20 6 cil: alcool com comando 250s e escap. 6x2 cambio 5 marchas","R$ 25.000");
		addDoc(w, "(19) 3886-2021", "", "BLAZER", "00","v6, mecanica completa, azul","R$ 24.500");
		addDoc(w, "(19) 3869-2621 (19) 3859-1505 (19) 9 8179-5882", "", "KOMBI", "96",
				"gasolina, branca.","R$ 12.000");
		addDoc(w, "(19) 9 9614-6821", "", "GOL", "89",
				"motor ap alcool roda 15 suspensao castor de rosca legalizado","R$ 6.500");
		addDoc(w, "(19) 3886-1688", "", "ASTRA", "08","4p, prata, completo","");
		addDoc(w, "(19) 4042-1075 - (19) 3500-2451", "", "COBALT", "16","manual, flex, marron.","R$ 54.990");
		addDoc(w, "(19) 4042-1075 - (19) 3500-2451", "", "ONIX", "14","manual, flex, vermelha.","R$ 38.990");
		addDoc(w, "(19) 3871-7591 - (19) 3929-6153 - (19) 7802-4753", "", "S10", "03","branco, diesel, completo.","");
		addDoc(w, "(19) 3886-2021", "", "CORSA", "08","spirit preto, competo","R$ 19.500");
		addDoc(w, "(19) 4042-1075 - (19) 3500-2451", "", "AGILE", "14","flex, branca, mecam","R$ 35.990");
		
		w.close();

		// 2. QUERY
		String querystr = args.length > 0 ? args[0] : "R$";

		// busca por todos os campos do arquivo
		Query q = null, q1 = null, q2 = null,
				q3 = null, q4 = null, q5 = null;
		try {
			q = new QueryParser(Version.LUCENE_40, "telefone", analyzer).parse(querystr);
			q1 = new QueryParser(Version.LUCENE_40, "email", analyzer).parse(querystr);
			q2 = new QueryParser(Version.LUCENE_40, "modelo", analyzer).parse(querystr);
			q3 = new QueryParser(Version.LUCENE_40, "ano", analyzer).parse(querystr);
			q4 = new QueryParser(Version.LUCENE_40, "detalhes", analyzer).parse(querystr);
			q5 = new QueryParser(Version.LUCENE_40, "valor", analyzer).parse(querystr);
			
		} catch (org.apache.lucene.queryparser.classic.ParseException e) {
			e.printStackTrace();
		}

		// mostrar top10
		int hitsPerPage = 10;
		IndexReader reader = DirectoryReader.open(index);
		IndexSearcher searcher = new IndexSearcher(reader);
		TopScoreDocCollector collector = TopScoreDocCollector.create(hitsPerPage, true);
		
		
		//Resultados
		searcher.search(q, collector);
		ScoreDoc[] hits = collector.topDocs().scoreDocs;
		
		System.out.println("Encontrado(s): ");
		if(hits.length > 0)
			printResult(searcher, hits);
		
		searcher.search(q1, collector);
		hits = collector.topDocs().scoreDocs;
		if(hits.length > 0)		
			printResult(searcher, hits);
			
		
		
		searcher.search(q2, collector);
		hits = collector.topDocs().scoreDocs;
		if(hits.length > 0) 
			printResult(searcher, hits);

		
		searcher.search(q3, collector);
		hits = collector.topDocs().scoreDocs;
		if(hits.length > 0)
			printResult(searcher, hits);
		
		searcher.search(q4, collector);
		hits = collector.topDocs().scoreDocs;
		if(hits.length > 0)
			printResult(searcher, hits);
		
		searcher.search(q5, collector);
		hits = collector.topDocs().scoreDocs;
		if(hits.length > 0)
			printResult(searcher, hits);

		reader.close();
	}

	private static void printResult(IndexSearcher searcher, ScoreDoc[] hits) throws IOException {
		if(hits.length > 0) {
			for (int i = 0; i < hits.length; ++i) {
				int docId = hits[i].doc;
				Document d = searcher.doc(docId);
				System.out.println((i + 1)+". " + d.get("modelo")+"; " + d.get("telefone")+"; "
					+ d.get("ano")+"; " + d.get("detalhes")+"; " + d.get("valor"));
			}
			
		}
		
	}
	private static void addDoc(IndexWriter w, String telefone, String email, String modelo,
			String ano, String detalhes, String valor) throws IOException {
		
		Document doc = new Document();
		doc.add(new TextField("telefone", telefone, Field.Store.YES));

		doc.add(new TextField("email", email, Field.Store.YES));
		
		doc.add(new TextField("modelo", modelo, Field.Store.YES));
		
		doc.add(new TextField("ano", ano, Field.Store.YES));
		
		doc.add(new TextField("detalhes", detalhes, Field.Store.YES));
		
		doc.add(new TextField("valor", valor, Field.Store.YES));
		
		w.addDocument(doc);
	}
	

}
